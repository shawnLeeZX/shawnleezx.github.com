#include <math.h>

#define POWER 8

int a = 0;

void increment_a()
{
  a++;
}

int main (int argc, char const* argv[])
{
    for (int i = 0; i < (int)pow(10, 8); i++)
      {
        a++;
        increment_a();
      }

    return 0;
}
