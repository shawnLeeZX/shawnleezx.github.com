#include "libstatic.h"

int main (int argc, char const* argv[])
{
    looper();
    return 0;
}
