void looper()
{
    int a = 0;
    for (int i = 0; i < 10000000; i++)
        {
            a++;
        }
}
